# Extraits originaux du chat

Source : [Projet SQL portfolio Analyst](chatgpt-conversation://6ab37d8c-8478-83ed-b79e-4d3abfdd72d8). Ces extraits sont conservés tels quels, y compris les erreurs de syntaxe. Ils ne constituent pas tous des requêtes exécutables. Les messages demandant une correction ne prouvent pas que leur texte a été exécuté.

## Message f2414356-8fe9-4dad-8386-032d87b86d4c

```text
C CORRect?     select year(order_purchase_timestamp) as order_year,
       month(order_purchase_timestamp) as order_month,
       count(*) as total_orders
       from orders
where order_purchase_timestamp is not null
group by year(order_purchase_timestamp),
         month(order_purchase_timestamp)
order by order_year,
         order_month;
```

## Message 61445624-960c-457c-b42e-e4ad28d33855

```text
select YEAR(order_purchase_timestamp) as year_orders, 
       COUNT(order_id) as numbers_id 
       from orders 
       where YEAR(order_purchase_timestamp) in (2017,2018) 
        and MONTH(order_purchase_timestamp) between 1 and 8 
        group by year(order_purchase_timestamp);
```

## Message a9340ff9-162b-4aa4-a3ec-5d03cc37e2da

```text
SELECT COUNT(DISTINCT P.product_category_name ) AS category_orders
FROM products AS P
INNER JOIN order_items AS I
    ON P.product_id = I.product_id
INNER JOIN orders AS O
    ON I.order_id = O.order_id
WHERE YEAR(O.order_purchase_timestamp) = 2017
    AND MONTH(O.order_purchase_timestamp) BETWEEN 1 AND 8;
```

## Message 64d12c39-5a13-4b16-80e2-59d519fb46a1

```text
corrige     select YEAR(O.order_purchase_timestamp) as order_years, 
       COUNT(distinct S.seller_id) 
       from sellers as S 
       inner join order_items as I 
       on S.seller_id = I.seller_id 
       inner join orders as O 
       on O.order_id = I.order_id 
       where YEAR(O.order_purchase_timestamp) in (2017,2018) 
         and MONTH(O.order_purchase_timestamp) between 1 and 8 
        group by YEAR(O.order_purchase_timestamp);
```

## Message a33698ca-b030-43bf-ae21-6b4ece012f20

```text
select YEAR(O.order_purchase_timestamp) as order_years, 
       COUNT( distinct S.seller_state) as numbers_states 
       from sellers as S 
       inner join order_items as I 
       on S.seller_id = I.seller_id 
       inner join orders as O 
       on O.order_id = I.order_id 
       where YEAR(O.order_purchase_timestamp) in (2017,2018) 
             and month(O.order_purchase_timestamp) between 1 and 8 
        group by  
              YEAR(O.order_purchase_timestamp);
```

## Message f8dbc05b-86a6-4077-8919-707fc7291d70

```text
corrige, je n'ai pas regardé tes indices ni le début de ta requête        SELECT
    YEAR(O.order_purchase_timestamp) AS order_years,
    S.seller_state AS state_names,
    COUNT(DISTINCT S.seller_id) AS number_of_sellers
FROM sellers AS S
INNER JOIN order_items AS I
    ON S.seller_id = I.seller_id
INNER JOIN orders AS O
    ON O.order_id = I.order_id
WHERE YEAR(O.order_purchase_timestamp) IN (2017, 2018)
    AND MONTH(O.order_purchase_timestamp) BETWEEN 1 AND 8
GROUP BY
    YEAR(O.order_purchase_timestamp),
    S.seller_state
ORDER BY
    order_years,
    state_names;
```

## Message 565c87bf-0064-4beb-b124-e169b757364d

```text
select  
       YEAR(O.order_purchase_timestamp) as orders_year, 
      COUNT(distinct C.customer_unique_id) as numbers_buyers 
      from customers as C 
      inner join orders as O 
      on C.customer_id = O.customer_id 
      where year(O.order_purchase_timestamp) in (2017,2018) 
      and month(O.order_purchase_timestamp) between 1 and 8 
      GROUP BY YEAR(O.order_purchase_timestamp), 
      order by 
               orders_year;
```

## Message 23b9f5f3-4dab-4248-8f97-3a169334221e

```text
corrige         select 
      S.seller_state,
      SUM(case when YEAR(O.order_purchase_timestamp) = 2017
          THEN I.price else O
          END) as revenue_per_state 2017,
      sum(case when year(O.order_purchase_timestamp) = 2018
         THEN I.price else 0
         end) as revenue_per_year 2018
       FROM orders as O
       inner join order_items as I
       on O.order_id = I.order_id
       inner join sellers as S
       on I.seller_id = S.seller_id
where year(O.order_purchase_timestamp) in (2017,2018)
  and month(O.order_purchase_timsestamp) between 1 and 8
GROUP BY S.seller_state
ORDER BY S.seller state;
```

## Message 35ed8c56-3dd7-4a3a-8d37-d21aa558aea3

```text
corrige             select
COUNT(distinct S.seller_city) as city_sellers
from sellers as S 
inner join order_items as I
on S.seller_id = I.seller_id
inner join orders as O
on I.order_id = O.order_id
where S.seller_state = 'SP'
     and YEAR(0.order_purchase_timestamp) in (2017,2018)
     and month(O.order_purchase_timestamp) between 1 and 8
 group by year(O.order_purchase_timestamp);
```

## Message b9ef94e1-e764-4598-925d-252839134f49

```text
corrige     WITH zip_state_count AS (
    SELECT
        geolocation_zip_code_prefix,
        geolocation_state,
        COUNT(*) AS nb_occurences
    FROM geolocation
    GROUP BY
        geolocation_zip_code_prefix,
        geolocation_state
),

zip_state_ranked AS (
    SELECT
        geolocation_zip_code_prefix,
        geolocation_state,
        nb_occurences,
        ROW_NUMBER() OVER (
            PARTITION BY geolocation_zip_code_prefix
            ORDER BY nb_occurences DESC, geolocation_state
        ) AS rang
    FROM zip_state_count
),

seller_geographic_check 
    SELECT
    s.seller_id,
    s.seller_zip_code_prefix,
    s.seller_state,
    z.geolocation_state AS etat_reference,

    CASE
        WHEN z.geolocation_state IS NULL
            THEN 'NOT FOUND'

        WHEN s.seller_state = z.geolocation_state
            THEN 'CONSISTENT'

        ELSE 'INCONSISTENT'
    END AS geographic_status

FROM sellers AS s
LEFT JOIN zip_state_ranked AS z
    ON s.seller_zip_code_prefix = z.geolocation_zip_code_prefix
    AND z.rang = 1)

    select distinct seller_id, geographic_status, 
           count(*) as seller_position
           from seller_geographic_check
           group by
                 seller_id,
                 geographic_status;
```
