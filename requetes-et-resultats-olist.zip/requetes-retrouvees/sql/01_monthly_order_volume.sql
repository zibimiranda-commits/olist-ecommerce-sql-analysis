-- Recovered/reconstructed from the analysis conversation.
-- Original query recovered; message f2414356-8fe9-4dad-8386-032d87b86d4c.
-- Prepared for SQL Server; NOT executed against SQL Server during recovery.
-- Read-only. Compare a fresh run with the recovered results before publication.
USE olist;
GO

SELECT YEAR(order_purchase_timestamp) AS order_year,
       MONTH(order_purchase_timestamp) AS order_month,
       COUNT(*) AS total_orders
FROM orders
WHERE order_purchase_timestamp IS NOT NULL
GROUP BY YEAR(order_purchase_timestamp), MONTH(order_purchase_timestamp)
ORDER BY order_year, order_month;
