# Requêtes et résultats retrouvés — Olist

Les fichiers de ce dossier ont été préparés à partir de la conversation « Projet SQL portfolio Analyst ». Aucune requête n'a été exécutée dans SQL Server pendant cette récupération. Aucun ancien script GitHub n'a été modifié. Les scripts préparés restent à exécuter dans la base d'origine.

## Ce qui est récupéré

| Étape | Script préparé | Résultats retrouvés | Statut du code |
| --- | --- | --- | --- |
| Volumes mensuels | [01](sql/01_monthly_order_volume.sql) | [25 lignes](resultats/01_commandes_mensuelles.txt), collées dans le chat | Requête originale retrouvée, mise en forme |
| Ventes et commandes | [02](sql/02_sales_and_orders.sql) | [Récapitulatif](resultats/02_comparaison_recapitulee.txt) ; les ventes sont aussi réconciliées avec les catégories et les États | Comptage original ; ventes sur huit mois reconstruites |
| Catégories | [03](sql/03_categories.sql) | [144 lignes](resultats/03_ventes_categories.txt), collées dans le chat | Comptage 2017 original ; comparaison et jointure de traduction reconstruites |
| Acheteurs et produits | [04](sql/04_buyers_and_products.sql) | Totaux du récapitulatif ; détail produits non retrouvé | Acheteurs : virgule corrigée ; produits : reconstruction |
| Vendeurs et États | [05](sql/05_sellers_and_states.sql) | [Vendeurs](resultats/05_vendeurs_par_etat.txt) et [ventes](resultats/05_ventes_par_etat.txt), collés dans le chat | Comptages retrouvés ; ventes conditionnelles corrigées |
| SP : produits et villes | [06](sql/06_sp_products_and_cities.sql) | 151 puis 258 libellés bruts dans le message 8ad69c83 ; pas de chiffre exact retrouvé pour les références SP | Villes : alias corrigé ; produits et listes : reconstruction |
| Géographie | [07](sql/07_seller_geographic_check.sql) | [Résumé](resultats/07_controle_geographique_resume.txt) collé dans le chat ; [3 095 lignes détaillées](resultats/07_controle_geographique_detail_original.txt) récupérées dans une pièce jointe | CTE et agrégation finale corrigées/reconstruites |

Les fichiers de résultats sont des transcriptions de sorties historiques, pas des exports d'une nouvelle exécution. Les en-têtes ont été ajoutés. Le récapitulatif 02 vient d'un tableau récapitulatif partagé, et non d'une sortie brute unique. Les extraits originaux, y compris les erreurs, sont conservés dans [sources/extraits_originaux.md](sources/extraits_originaux.md).

## Vérifications obtenues sans relancer la base

- La somme des ventes par catégorie donne exactement 3 113 000,32 R$ en 2017 et 7 385 905,80 R$ en 2018, catégories NULL comprises.
- La somme des ventes par État donne les mêmes montants.
- Le tableau compte 70 catégories non NULL en 2017 et 72 en 2018.
- Trois catégories apparaissent : `portateis_cozinha_e_preparadores_de_alimentos` (3 968,53 R$), `fraldas_higiene` (1 356,69 R$), `flores` (839,54 R$). Total : **6 164,76 R$**. Le calcul est maintenant réconcilié avec les lignes détaillées retrouvées.
- `seguros_e_servicos` est présente en 2017 et absente en 2018 : trois apparitions moins une disparition expliquent le solde de deux catégories.
- La catégorie de 3 968,53 R$ n'a pas de traduction anglaise dans la sortie retrouvée. Une jointure interne avec la table de traduction pourrait donc l'exclure ; le script préparé conserve cette catégorie avec une jointure gauche.
- Les volumes mensuels de janvier à août totalisent 22 968 puis 53 991 commandes.

## Provenance des sorties

- Commandes mensuelles : message `25f89b51-ccc0-4fe0-8b5d-e14ef6b18446`.
- Catégories et traductions : `d3bb0a83-e5fa-43e8-a66b-c0794f5003c4`.
- Vendeurs par État : `722e35bb-728a-4798-ab3d-0e7c799602ee`.
- Ventes par État : `cd9b4517-f00f-4c66-9437-ca266fc9fdc7`.
- Tableau récapitulatif : `c0360f56-3211-4d58-85df-7beb234cb1e1` ; catégories : `d936ca01-e2c0-455d-8581-f3c4fd689e7a`.
- Statuts géographiques : `0df11b42-36fe-4eed-8755-38c0e7043b63`.

Le détail géographique provient de la pièce jointe `Pasted text(20261015-173517).txt`. Ses 3 095 identifiants vendeurs sont distincts. Les libellés originaux sont conservés : `COHERENT` (3 053), `INCOHERENT` (35), `NON TROUVE` (7), correspondant aux statuts anglais du résumé. Il s’agit du fichier historique retrouvé, pas d’un nouveau résultat SQL.

## Ce qui reste à retrouver ou confirmer

- Le texte exact de plusieurs requêtes finales corrigées : les réponses de l'ancien assistant sont restituées sous forme de références sans leur contenu.
- Les résultats détaillés par produit et les nombres exacts de références vendues dans SP.
- La définition précise des comptages de villes 147/209 et des « 55 villes », ainsi que leur contribution aux ventes. Ces résultats ne sont pas remplacés par les comptages bruts 151/258.
- Les aperçus de nettoyage ne prouvent pas une mise à jour des tables. Aucune correction géographique n'est présentée comme réalisée.

Avant toute nouvelle exécution, sélectionner la base `olist`, vérifier les doublons des identifiants et conserver les sorties séparément. Les scripts de ce dossier sont uniquement des SELECT/CTE, précédés de USE ; ils ne recréent pas la base et ne modifient aucune table.

Source des données : [Brazilian E-Commerce Public Dataset by Olist](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce). Les sorties et résumés dérivés sont partagés sous [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/), avec attribution à Olist. Projet indépendant, sans affiliation. Cette notice ne donne pas de licence au code SQL.
